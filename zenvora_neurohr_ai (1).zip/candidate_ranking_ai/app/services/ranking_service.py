"""
Module  : services/ranking_service.py
Purpose : Central orchestration service for candidate ranking.
          Coordinates:
            - Skill analysis
            - Experience analysis
            - Fraud detection
            - Resume quality assessment
            - Explainability layer
            - Score computation with adaptive weights
            - Response assembly

All public methods are async to align with FastAPI's async paradigm.
"""

from __future__ import annotations

from app.schemas.ranking_schema import (
    CandidateInput,
    JobRequirements,
    WeightConfig,
    CandidateRankingResult,
    ScoreBreakdown,
    SkillAnalysis,
    ExperienceAnalysis,
    FraudAnalysis,
    ResumeQuality,
    RankedCandidate,
    RankMultipleResponse,
    JobMatchResponse,
)
from app.core.config import settings
from app.core.logger import setup_logger

from app.utils.skill_matcher import (
    analyse_skills,
    skill_score_from_analysis,
    detect_skill_categories,
    detect_domain,
)
from app.utils.scoring_utils import (
    score_education,
    score_certifications,
    score_projects,
    score_experience,
    resolve_ranking_level,
    resolve_hiring_recommendation,
    calculate_confidence,
    calculate_data_completeness,
    clamp,
)
from app.utils.fraud_detector import analyse_fraud
from app.utils.resume_quality import analyse_resume_quality
from app.utils.explainability import (
    generate_strengths,
    generate_weaknesses,
    generate_smart_insights,
    generate_tags,
    recommend_role,
    generate_improvements,
)

logger = setup_logger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
#  Weight Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _resolve_weights(weights: WeightConfig | None) -> WeightConfig:
    """Return provided weights or fall back to system defaults."""
    if weights is not None:
        return weights
    return WeightConfig(
        skills_weight=settings.DEFAULT_SKILLS_WEIGHT,
        experience_weight=settings.DEFAULT_EXPERIENCE_WEIGHT,
        projects_weight=settings.DEFAULT_PROJECTS_WEIGHT,
        education_weight=settings.DEFAULT_EDUCATION_WEIGHT,
        certs_weight=settings.DEFAULT_CERTS_WEIGHT,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  Core Ranking Pipeline
# ═══════════════════════════════════════════════════════════════════════════════

async def rank_single_candidate(
    candidate: CandidateInput,
    job: JobRequirements,
    weights: WeightConfig | None = None,
) -> CandidateRankingResult:
    """
    Full ranking pipeline for a single candidate against a job.

    Returns a CandidateRankingResult with complete analysis.
    """
    w = _resolve_weights(weights)
    logger.info(f"Ranking candidate: {candidate.name!r} for role: {job.job_role!r}")

    # ── 1. Skill Analysis ─────────────────────────────────────────────────────
    skill_analysis_raw = analyse_skills(
        candidate_skills=candidate.skills,
        required_skills=job.required_skills,
        nice_to_have=job.nice_to_have_skills,
    )
    skill_score = skill_score_from_analysis(skill_analysis_raw)

    # ── 2. Experience Analysis ────────────────────────────────────────────────
    exp_score, exp_status, exp_gap = score_experience(
        candidate.experience, job.required_experience
    )

    # ── 3. Project Score ──────────────────────────────────────────────────────
    proj_score = score_projects(candidate.projects)

    # ── 4. Education Score ────────────────────────────────────────────────────
    edu_score = score_education(candidate.education)

    # ── 5. Certification Score ────────────────────────────────────────────────
    cert_score = score_certifications(candidate.certifications)

    # ── 6. Weighted Total ─────────────────────────────────────────────────────
    weighted_total = (
        skill_score     * (w.skills_weight     / 100.0)
        + exp_score     * (w.experience_weight / 100.0)
        + proj_score    * (w.projects_weight   / 100.0)
        + edu_score     * (w.education_weight  / 100.0)
        + cert_score    * (w.certs_weight      / 100.0)
    )
    final_score = clamp(round(weighted_total, 2))

    # ── 7. Fraud Analysis ─────────────────────────────────────────────────────
    fraud_raw = analyse_fraud(
        skills=candidate.skills,
        experience=candidate.experience,
        projects=candidate.projects,
        certifications=candidate.certifications,
    )

    # ── 8. Resume Quality ─────────────────────────────────────────────────────
    quality_raw = analyse_resume_quality(
        skills=candidate.skills,
        experience=candidate.experience,
        education=candidate.education,
        projects=candidate.projects,
        certifications=candidate.certifications,
        summary=candidate.summary,
    )

    # ── 9. Skill Categories & Domain ─────────────────────────────────────────
    skill_categories = detect_skill_categories(candidate.skills)
    domain = detect_domain(candidate.skills, job.job_role)

    # ── 10. Explainability ───────────────────────────────────────────────────
    strengths = generate_strengths(
        skill_match_pct=skill_analysis_raw["skill_match_percentage"],
        matched_skills=skill_analysis_raw["matched_skills"],
        experience_status=exp_status,
        projects=candidate.projects,
        certifications=candidate.certifications,
        education_score=edu_score,
        skill_categories=skill_categories,
    )

    weaknesses = generate_weaknesses(
        missing_skills=skill_analysis_raw["missing_skills"],
        experience_status=exp_status,
        candidate_exp=candidate.experience,
        required_exp=job.required_experience,
        certifications=candidate.certifications,
        skill_match_pct=skill_analysis_raw["skill_match_percentage"],
    )

    smart_insights = generate_smart_insights(
        final_score=final_score,
        skill_match_pct=skill_analysis_raw["skill_match_percentage"],
        related_skills=skill_analysis_raw["related_skills_detected"],
        fraud_risk=fraud_raw["fraud_risk_score"],
        experience_status=exp_status,
        domain=domain,
    )

    tags = generate_tags(
        final_score=final_score,
        skill_categories=skill_categories,
        certifications=candidate.certifications,
        experience_status=exp_status,
        projects=candidate.projects,
        domain=domain,
        skill_match_pct=skill_analysis_raw["skill_match_percentage"],
    )

    recommended_role = recommend_role(
        job_role=job.job_role,
        final_score=final_score,
        skill_categories=skill_categories,
        experience_status=exp_status,
    )

    improvements = generate_improvements(
        missing_skills=skill_analysis_raw["missing_skills"],
        certifications=candidate.certifications,
        projects=candidate.projects,
        education_score=edu_score,
        experience_status=exp_status,
    )

    # ── 11. Confidence Score ─────────────────────────────────────────────────
    completeness = calculate_data_completeness(candidate.model_dump())
    confidence = calculate_confidence(
        skill_match_pct=skill_analysis_raw["skill_match_percentage"],
        fraud_risk_score=fraud_raw["fraud_risk_score"],
        data_completeness=completeness,
    )

    # ── 12. Assemble Response ────────────────────────────────────────────────
    return CandidateRankingResult(
        candidate_name=candidate.name,
        job_role=job.job_role,
        final_score=final_score,
        ranking_level=resolve_ranking_level(final_score),
        confidence_score=round(confidence, 2),
        score_breakdown=ScoreBreakdown(
            skills_score=round(skill_score, 2),
            experience_score=round(exp_score, 2),
            projects_score=round(proj_score, 2),
            education_score=round(edu_score, 2),
            certifications_score=round(cert_score, 2),
            weighted_total=final_score,
        ),
        skill_analysis=SkillAnalysis(**skill_analysis_raw),
        experience_analysis=ExperienceAnalysis(
            candidate_experience=candidate.experience,
            required_experience=job.required_experience,
            experience_score=round(exp_score, 2),
            experience_status=exp_status,
            gap_years=round(exp_gap, 1),
        ),
        resume_quality=ResumeQuality(**quality_raw),
        strengths=strengths,
        weaknesses=weaknesses,
        smart_insights=smart_insights,
        recommended_role=recommended_role,
        suggested_improvements=improvements,
        candidate_tags=tags,
        hiring_recommendation=resolve_hiring_recommendation(final_score),
        fraud_analysis=FraudAnalysis(
            fraud_risk_score=fraud_raw["fraud_risk_score"],
            fraud_risk_level=fraud_raw["fraud_risk_level"],
            fraud_warnings=fraud_raw["fraud_warnings"],
            is_suspicious=fraud_raw["is_suspicious"],
        ),
        skill_categories_detected=skill_categories,
        domain_detected=domain,
        weights_used={
            "skills":      w.skills_weight,
            "experience":  w.experience_weight,
            "projects":    w.projects_weight,
            "education":   w.education_weight,
            "certs":       w.certs_weight,
        },
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  Multi-Candidate Ranking
# ═══════════════════════════════════════════════════════════════════════════════

async def rank_multiple_candidates(
    candidates: list[CandidateInput],
    job: JobRequirements,
    weights: WeightConfig | None = None,
    top_n: int = 10,
) -> RankMultipleResponse:
    """
    Rank a batch of candidates and return sorted results with summary analytics.
    """
    logger.info(f"Batch ranking {len(candidates)} candidates for: {job.job_role!r}")

    results: list[CandidateRankingResult] = []
    for candidate in candidates:
        result = await rank_single_candidate(candidate, job, weights)
        results.append(result)

    # Sort descending by final score
    results.sort(key=lambda r: r.final_score, reverse=True)
    top_results = results[:top_n]

    ranked: list[RankedCandidate] = []
    for idx, res in enumerate(top_results, start=1):
        ranked.append(
            RankedCandidate(
                rank=idx,
                candidate_name=res.candidate_name,
                final_score=res.final_score,
                ranking_level=res.ranking_level,
                hiring_recommendation=res.hiring_recommendation,
                candidate_tags=res.candidate_tags,
                top_strengths=res.strengths[:2],
                missing_skills=res.skill_analysis.missing_skills[:3],
                fraud_risk_level=res.fraud_analysis.fraud_risk_level,
                full_result=res,
            )
        )

    # Summary analytics
    scores = [r.final_score for r in results]
    level_counts: dict[str, int] = {}
    for r in results:
        level_counts[r.ranking_level] = level_counts.get(r.ranking_level, 0) + 1

    import numpy as np
    summary = {
        "average_score":   round(float(np.mean(scores)), 2) if scores else 0,
        "highest_score":   round(max(scores), 2) if scores else 0,
        "lowest_score":    round(min(scores), 2) if scores else 0,
        "std_deviation":   round(float(np.std(scores)), 2) if scores else 0,
        "level_distribution": level_counts,
        "strongly_recommended": sum(
            1 for r in results if r.hiring_recommendation == "Strongly Recommend"
        ),
        "suspicious_profiles": sum(
            1 for r in results if r.fraud_analysis.is_suspicious
        ),
    }

    return RankMultipleResponse(
        job_role=job.job_role,
        total_candidates=len(candidates),
        top_n_returned=len(ranked),
        ranked_candidates=ranked,
        summary=summary,
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  Job Match Analysis
# ═══════════════════════════════════════════════════════════════════════════════

async def analyse_job_match(
    candidate: CandidateInput,
    job: JobRequirements,
) -> JobMatchResponse:
    """
    Deep-dive compatibility analysis between a candidate and a job.
    Focuses on gap analysis and actionable next steps.
    """
    skill_analysis_raw = analyse_skills(
        candidate_skills=candidate.skills,
        required_skills=job.required_skills,
        nice_to_have=job.nice_to_have_skills,
    )

    exp_score, exp_status, exp_gap = score_experience(
        candidate.experience, job.required_experience
    )

    # Compatibility score: weighted combination
    compat_score = clamp(
        skill_analysis_raw["skill_match_percentage"] * 0.6 + exp_score * 0.4
    )

    # Build skill gap report
    gap_analysis = {
        "required_skills_total": len(job.required_skills),
        "matched_count":         len(skill_analysis_raw["matched_skills"]),
        "related_count":         len(skill_analysis_raw["related_skills_detected"]),
        "missing_count":         len(skill_analysis_raw["missing_skills"]),
        "match_percentage":      skill_analysis_raw["skill_match_percentage"],
        "matched_skills":        skill_analysis_raw["matched_skills"],
        "related_skills":        skill_analysis_raw["related_skills_detected"],
        "missing_skills":        skill_analysis_raw["missing_skills"],
        "nice_to_have_matched":  skill_analysis_raw["nice_to_have_matched"],
        "experience_status":     exp_status,
        "experience_gap_years":  exp_gap,
    }

    # Action items
    action_items: list[str] = []
    if skill_analysis_raw["missing_skills"]:
        action_items.append(
            f"Bridge skill gaps: {', '.join(skill_analysis_raw['missing_skills'][:4])}."
        )
    if exp_status == "Underqualified":
        action_items.append(
            f"Gain {abs(exp_gap):.1f} more year(s) of relevant experience."
        )
    if not candidate.certifications:
        action_items.append("Obtain a recognised certification to strengthen profile.")
    if not candidate.projects:
        action_items.append("Add portfolio projects demonstrating hands-on delivery.")

    recommendation = (
        "Strong match — proceed to interview."        if compat_score >= 75 else
        "Moderate match — consider after screening."  if compat_score >= 55 else
        "Weak match — significant gaps present."
    )

    return JobMatchResponse(
        candidate_name=candidate.name,
        job_role=job.job_role,
        compatibility_score=round(compat_score, 2),
        skill_gap_analysis=gap_analysis,
        recommendation=recommendation,
        action_items=action_items,
    )
