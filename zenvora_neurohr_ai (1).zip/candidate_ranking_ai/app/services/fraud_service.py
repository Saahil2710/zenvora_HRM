"""
Module  : services/fraud_service.py
Purpose : Thin service layer wrapping the fraud detection utilities,
          preparing the full FraudCheckResponse for the API router.
"""

from __future__ import annotations

from app.schemas.ranking_schema import CandidateInput, FraudCheckResponse, FraudAnalysis
from app.utils.fraud_detector import analyse_fraud
from app.core.logger import setup_logger

logger = setup_logger(__name__)


async def check_candidate_fraud(candidate: CandidateInput) -> FraudCheckResponse:
    """
    Run complete fraud heuristics on a candidate and return a detailed report.
    """
    logger.info(f"Fraud check: {candidate.name!r}")

    fraud_raw = analyse_fraud(
        skills=candidate.skills,
        experience=candidate.experience,
        projects=candidate.projects,
        certifications=candidate.certifications,
    )

    return FraudCheckResponse(
        candidate_name=candidate.name,
        fraud_analysis=FraudAnalysis(
            fraud_risk_score=fraud_raw["fraud_risk_score"],
            fraud_risk_level=fraud_raw["fraud_risk_level"],
            fraud_warnings=fraud_raw["fraud_warnings"],
            is_suspicious=fraud_raw["is_suspicious"],
        ),
        detailed_flags=fraud_raw.get("_detailed_flags", []),
    )
