# app/schemas/__init__.py
from app.schemas.ranking_schema import *  # noqa: F401,F403
