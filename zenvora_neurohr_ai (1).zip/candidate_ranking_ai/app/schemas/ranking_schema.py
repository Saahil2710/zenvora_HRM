"""
Module  : schemas/ranking_schema.py
Purpose : Pydantic request / response models with full validation.
          All public API contracts are defined here.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, field_validator, model_validator


# ═══════════════════════════════════════════════════════════════════════════════
#  REQUEST SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class CandidateInput(BaseModel):
    """Parsed resume data forwarded by the MERN backend team."""

    name: str = Field(..., min_length=2, max_length=120, examples=["Rahul Sharma"])
    skills: List[str] = Field(..., min_length=1, examples=[["Python", "FastAPI", "SQL"]])
    experience: float = Field(..., ge=0, le=60, examples=[2])
    education: str = Field(
        ..., examples=["B.Tech"],
        description="Highest qualification: PhD, M.Tech, B.Tech, BCA, Diploma, etc.",
    )
    projects: List[str] = Field(default_factory=list, examples=[["AI Resume Parser"]])
    certifications: List[str] = Field(default_factory=list, examples=[["AWS Cloud Practitioner"]])
    summary: Optional[str] = Field(None, max_length=2000, description="Optional profile summary")

    @field_validator("skills", mode="before")
    @classmethod
    def normalise_skills(cls, v: List[str]) -> List[str]:
        return [s.strip() for s in v if s.strip()]


class JobRequirements(BaseModel):
    """Job description provided by the recruiter."""

    job_role: str = Field(..., min_length=2, max_length=120, examples=["Backend Developer"])
    required_skills: List[str] = Field(..., min_length=1, examples=[["Python", "FastAPI", "Docker"]])
    required_experience: float = Field(..., ge=0, le=40, examples=[2])
    nice_to_have_skills: List[str] = Field(default_factory=list)
    domain: Optional[str] = Field(None, examples=["FinTech", "HealthTech"])

    @field_validator("required_skills", mode="before")
    @classmethod
    def normalise_required(cls, v: List[str]) -> List[str]:
        return [s.strip() for s in v if s.strip()]


class WeightConfig(BaseModel):
    """
    Adaptive weight configuration — allows recruiters to reprioritise scoring.
    All values are percentages and must sum to 100.
    """

    skills_weight: float     = Field(50.0, ge=0, le=100)
    experience_weight: float = Field(25.0, ge=0, le=100)
    projects_weight: float   = Field(10.0, ge=0, le=100)
    education_weight: float  = Field(10.0, ge=0, le=100)
    certs_weight: float      = Field( 5.0, ge=0, le=100)

    @model_validator(mode="after")
    def weights_must_sum_to_100(self) -> "WeightConfig":
        total = (
            self.skills_weight
            + self.experience_weight
            + self.projects_weight
            + self.education_weight
            + self.certs_weight
        )
        if abs(total - 100.0) > 0.5:
            raise ValueError(
                f"All weights must sum to 100. Got {total:.1f}. "
                "Please adjust your weight configuration."
            )
        return self


class RankCandidateRequest(BaseModel):
    """Payload for POST /rank-candidate"""

    candidate: CandidateInput
    job: JobRequirements
    weights: Optional[WeightConfig] = Field(
        default=None,
        description="Optional adaptive weights. Defaults are used if omitted.",
    )


class RankMultipleCandidatesRequest(BaseModel):
    """Payload for POST /rank-multiple-candidates"""

    candidates: List[CandidateInput] = Field(..., min_length=1, max_length=50)
    job: JobRequirements
    weights: Optional[WeightConfig] = None
    top_n: int = Field(10, ge=1, le=50, description="Return top-N ranked candidates")


class JobMatchRequest(BaseModel):
    """Payload for POST /analyze-job-match"""

    candidate: CandidateInput
    job: JobRequirements


class FraudCheckRequest(BaseModel):
    """Payload for POST /fraud-check"""

    candidate: CandidateInput


# ═══════════════════════════════════════════════════════════════════════════════
#  RESPONSE SCHEMAS
# ═══════════════════════════════════════════════════════════════════════════════

class ScoreBreakdown(BaseModel):
    """Granular scoring by dimension — drives explainability."""

    skills_score: float
    experience_score: float
    projects_score: float
    education_score: float
    certifications_score: float
    weighted_total: float


class SkillAnalysis(BaseModel):
    matched_skills: List[str]
    related_skills_detected: List[str]   # e.g. "React → JavaScript"
    missing_skills: List[str]
    nice_to_have_matched: List[str]
    skill_match_percentage: float


class ExperienceAnalysis(BaseModel):
    candidate_experience: float
    required_experience: float
    experience_score: float
    experience_status: str    # "Exact Match", "Overqualified", "Underqualified"
    gap_years: float


class FraudAnalysis(BaseModel):
    fraud_risk_score: float           # 0–100
    fraud_risk_level: str             # Low / Medium / High
    fraud_warnings: List[str]
    is_suspicious: bool


class ResumeQuality(BaseModel):
    quality_score: float      # 0–100
    quality_level: str        # Excellent / Good / Average / Poor
    quality_insights: List[str]


class CandidateRankingResult(BaseModel):
    """Complete ranking result for a single candidate."""

    # Identity
    candidate_name: str
    job_role: str

    # Core Score
    final_score: float
    ranking_level: str       # Excellent / Good / Average / Below Average / Poor
    confidence_score: float  # AI confidence in this ranking

    # Breakdown
    score_breakdown: ScoreBreakdown
    skill_analysis: SkillAnalysis
    experience_analysis: ExperienceAnalysis
    resume_quality: ResumeQuality

    # Explainability
    strengths: List[str]
    weaknesses: List[str]
    smart_insights: List[str]

    # Recommendations
    recommended_role: str
    suggested_improvements: List[str]
    candidate_tags: List[str]
    hiring_recommendation: str   # "Strongly Recommend" / "Recommend" / "Consider" / "Not Recommended"

    # Fraud
    fraud_analysis: FraudAnalysis

    # Meta
    skill_categories_detected: Dict[str, List[str]]
    domain_detected: str
    weights_used: Dict[str, float]


class RankedCandidate(BaseModel):
    """Lightweight ranking entry used in batch results."""

    rank: int
    candidate_name: str
    final_score: float
    ranking_level: str
    hiring_recommendation: str
    candidate_tags: List[str]
    top_strengths: List[str]
    missing_skills: List[str]
    fraud_risk_level: str
    full_result: CandidateRankingResult


class RankMultipleResponse(BaseModel):
    job_role: str
    total_candidates: int
    top_n_returned: int
    ranked_candidates: List[RankedCandidate]
    summary: Dict[str, Any]


class JobMatchResponse(BaseModel):
    candidate_name: str
    job_role: str
    compatibility_score: float
    skill_gap_analysis: Dict[str, Any]
    recommendation: str
    action_items: List[str]


class FraudCheckResponse(BaseModel):
    candidate_name: str
    fraud_analysis: FraudAnalysis
    detailed_flags: List[Dict[str, Any]]
