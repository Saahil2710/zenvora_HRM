"""
Module  : utils/explainability.py
Purpose : Explainable AI layer.
          Converts raw scores and analysis data into natural-language
          strengths, weaknesses, smart insights, tags, and recommendations.
"""

from __future__ import annotations

import random


# ═══════════════════════════════════════════════════════════════════════════════
#  Strengths Generator
# ═══════════════════════════════════════════════════════════════════════════════

def generate_strengths(
    skill_match_pct: float,
    matched_skills: list[str],
    experience_status: str,
    projects: list[str],
    certifications: list[str],
    education_score: float,
    skill_categories: dict[str, list[str]],
) -> list[str]:
    """Generate positive observations about the candidate."""
    strengths: list[str] = []

    # Skill strengths
    if skill_match_pct >= 90:
        strengths.append("Outstanding skill alignment — covers nearly all required competencies.")
    elif skill_match_pct >= 75:
        strengths.append(f"Strong skill coverage ({skill_match_pct:.0f}% match) for the role.")
    elif skill_match_pct >= 50:
        strengths.append(f"Solid foundational skills with {len(matched_skills)} direct matches.")

    # Category strengths
    for category in ["Backend", "Frontend", "DevOps & Cloud", "Data Science & ML"]:
        if category in skill_categories and len(skill_categories[category]) >= 2:
            strengths.append(
                f"Demonstrated {category} expertise: {', '.join(skill_categories[category][:3])}."
            )

    # Experience strengths
    if experience_status == "Exact Match":
        strengths.append("Experience level precisely matches the job requirement.")
    elif experience_status == "Overqualified":
        strengths.append("Senior-level experience brings additional depth and reliability.")

    # Project strengths
    if len(projects) >= 3:
        strengths.append(f"Rich project portfolio with {len(projects)} demonstrated deliverables.")
    elif len(projects) >= 1:
        strengths.append("Real-world project experience demonstrates practical application.")

    # Certification strengths
    if len(certifications) >= 2:
        strengths.append(
            f"Multiple industry certifications ({', '.join(certifications[:2])}) signal commitment."
        )
    elif certifications:
        strengths.append(f"Certified professional: {certifications[0]}.")

    # Education strengths
    if education_score >= 85:
        strengths.append("Advanced academic qualifications support technical depth.")
    elif education_score >= 70:
        strengths.append("Solid academic foundation relevant to the role.")

    return strengths[:6]  # cap at 6 strengths


# ═══════════════════════════════════════════════════════════════════════════════
#  Weaknesses Generator
# ═══════════════════════════════════════════════════════════════════════════════

def generate_weaknesses(
    missing_skills: list[str],
    experience_status: str,
    candidate_exp: float,
    required_exp: float,
    certifications: list[str],
    skill_match_pct: float,
) -> list[str]:
    """Generate honest gap observations."""
    weaknesses: list[str] = []

    if missing_skills:
        top_missing = missing_skills[:3]
        weaknesses.append(
            f"Missing {len(missing_skills)} required skill(s): {', '.join(top_missing)}"
            + (" and more." if len(missing_skills) > 3 else ".")
        )

    if experience_status == "Underqualified":
        gap = abs(required_exp - candidate_exp)
        weaknesses.append(
            f"Experience gap of {gap:.1f} year(s) below the required {required_exp:.0f} years."
        )

    if not certifications:
        weaknesses.append("No industry certifications listed — consider adding relevant credentials.")

    if skill_match_pct < 40:
        weaknesses.append("Limited overlap with the core technical stack required for this role.")

    # Check for cloud/DevOps gaps
    cloud_skills = {"aws", "gcp", "azure", "cloud", "docker", "kubernetes"}
    if any(s.lower() in cloud_skills for s in missing_skills):
        weaknesses.append("Missing cloud or containerisation skills valued for modern deployments.")

    return weaknesses[:5]


# ═══════════════════════════════════════════════════════════════════════════════
#  Smart Insights Generator
# ═══════════════════════════════════════════════════════════════════════════════

def generate_smart_insights(
    final_score: float,
    skill_match_pct: float,
    related_skills: list[str],
    fraud_risk: float,
    experience_status: str,
    domain: str,
) -> list[str]:
    """Generate AI-flavoured analytical observations."""
    insights: list[str] = []

    # Score summary
    if final_score >= 85:
        insights.append(
            f"Composite AI score of {final_score:.1f}/100 places this candidate in the top tier."
        )

    # Related skills bridge
    if related_skills:
        insights.append(
            f"{len(related_skills)} adjacent skill(s) detected — candidate likely adaptable "
            "to missing areas with a short ramp-up."
        )

    # Domain fit
    insights.append(f"Domain alignment detected: {domain}.")

    # Fraud
    if fraud_risk < 20:
        insights.append("Resume integrity check passed — profile appears authentic and consistent.")
    elif fraud_risk > 60:
        insights.append("⚠️ Elevated fraud risk signals — manual review recommended before shortlisting.")

    # Adaptability signal
    if experience_status == "Overqualified":
        insights.append(
            "Candidate is overqualified — consider whether growth opportunities exist to retain them."
        )

    if skill_match_pct >= 80 and final_score >= 75:
        insights.append(
            "High skill-to-score correlation suggests profile is internally consistent — low interview risk."
        )

    return insights[:5]


# ═══════════════════════════════════════════════════════════════════════════════
#  Candidate Tags
# ═══════════════════════════════════════════════════════════════════════════════

def generate_tags(
    final_score: float,
    skill_categories: dict[str, list[str]],
    certifications: list[str],
    experience_status: str,
    projects: list[str],
    domain: str,
    skill_match_pct: float,
) -> list[str]:
    """Generate descriptive candidate tags."""
    tags: list[str] = []

    # Score-based
    if final_score >= 88:
        tags.append("🌟 Top Candidate")
    elif final_score >= 75:
        tags.append("✅ Strong Candidate")
    elif final_score >= 60:
        tags.append("🔶 Potential Candidate")

    # Category-based
    for cat in ["Backend", "Frontend", "DevOps & Cloud", "Data Science & ML", "Mobile"]:
        if cat in skill_categories and len(skill_categories[cat]) >= 2:
            tags.append(f"💻 {cat} Specialist")

    # Domain
    if "AI" in domain or "ML" in domain:
        tags.append("🤖 AI Enthusiast")
    if "DevOps" in domain:
        tags.append("⚙️ DevOps Expert")
    if "FinTech" in domain:
        tags.append("💰 FinTech Background")

    # Experience
    if experience_status == "Overqualified":
        tags.append("🎯 Senior Level")
    elif experience_status == "Exact Match":
        tags.append("✔️ Right Fit")

    # Certs
    if certifications:
        tags.append("📜 Certified Professional")

    # Projects
    if len(projects) >= 4:
        tags.append("🛠️ Hands-On Builder")

    # Skill match
    if skill_match_pct == 100.0:
        tags.append("💯 Full Stack Match")

    return list(dict.fromkeys(tags))[:7]  # deduplicate, cap at 7


# ═══════════════════════════════════════════════════════════════════════════════
#  Recommended Role & Suggested Improvements
# ═══════════════════════════════════════════════════════════════════════════════

def recommend_role(
    job_role: str,
    final_score: float,
    skill_categories: dict[str, list[str]],
    experience_status: str,
) -> str:
    """Suggest the best-fit role based on profile analysis."""
    if final_score >= 75:
        return job_role  # role is a great fit

    # Fallback based on strongest category
    if skill_categories:
        strongest = max(skill_categories, key=lambda c: len(skill_categories[c]))
        category_role_map = {
            "Backend":            "Backend Developer",
            "Frontend":           "Frontend Developer",
            "DevOps & Cloud":     "DevOps / Cloud Engineer",
            "Data Science & ML":  "Data Scientist / ML Engineer",
            "Mobile":             "Mobile Developer",
            "Database":           "Database Administrator",
            "Security":           "Security Engineer",
        }
        return category_role_map.get(strongest, job_role)

    return job_role


def generate_improvements(
    missing_skills: list[str],
    certifications: list[str],
    projects: list[str],
    education_score: float,
    experience_status: str,
) -> list[str]:
    """Return concrete improvement recommendations."""
    improvements: list[str] = []

    if missing_skills:
        top = missing_skills[:3]
        improvements.append(
            f"Acquire proficiency in: {', '.join(top)} to improve role fit."
        )

    if not certifications:
        improvements.append(
            "Pursue a relevant industry certification (e.g., AWS, GCP, Kubernetes) to differentiate."
        )

    if len(projects) < 2:
        improvements.append(
            "Build and publish at least 2 portfolio projects showcasing end-to-end delivery."
        )

    if education_score < 50:
        improvements.append(
            "Consider enrolling in an online programme or bootcamp to strengthen formal qualifications."
        )

    if experience_status == "Underqualified":
        improvements.append(
            "Bridge the experience gap via open-source contributions or freelance projects."
        )

    return improvements[:5]
