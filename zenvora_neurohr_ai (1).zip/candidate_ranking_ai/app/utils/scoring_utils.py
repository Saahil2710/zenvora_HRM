"""
Module  : utils/scoring_utils.py
Purpose : Pure utility functions for score calculation, normalisation,
          label resolution, and helper math.  No side-effects.
"""

from __future__ import annotations

from app.data.skill_knowledge_base import (
    RANKING_LEVELS,
    HIRING_RECOMMENDATIONS,
    EDUCATION_SCORE_MAP,
    DEFAULT_EDUCATION_SCORE,
)


# ── Normalisation ─────────────────────────────────────────────────────────────

def clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    """Clamp a float value between lo and hi."""
    return max(lo, min(hi, value))


def normalise_to_100(value: float, max_value: float) -> float:
    """Scale `value` relative to `max_value` → [0, 100]."""
    if max_value <= 0:
        return 0.0
    return clamp((value / max_value) * 100.0)


# ── Label Resolution ──────────────────────────────────────────────────────────

def resolve_ranking_level(score: float) -> str:
    """Map a numeric score to a human-readable ranking level."""
    for threshold, label in RANKING_LEVELS:
        if score >= threshold:
            return label
    return "Poor"


def resolve_hiring_recommendation(score: float) -> str:
    """Map a numeric score to a hiring recommendation string."""
    for threshold, label in HIRING_RECOMMENDATIONS:
        if score >= threshold:
            return label
    return "Not Recommended"


# ── Education Scoring ─────────────────────────────────────────────────────────

def score_education(education: str) -> float:
    """
    Return an education score (0–100) based on qualification tier.
    Case-insensitive fuzzy match against the knowledge-base map.
    """
    edu_lower = education.lower().strip()
    for key, score in EDUCATION_SCORE_MAP.items():
        if key in edu_lower or edu_lower in key:
            return score
    return DEFAULT_EDUCATION_SCORE


# ── Certification Scoring ─────────────────────────────────────────────────────

# Certification tier weights
_CERT_TIER: dict[str, float] = {
    "aws":            20.0,
    "gcp":            20.0,
    "azure":          20.0,
    "kubernetes":     18.0,
    "ckad":           18.0,
    "cka":            18.0,
    "google":         16.0,
    "cisco":          16.0,
    "pmp":            15.0,
    "cissp":          15.0,
    "tensorflow":     14.0,
    "professional":   12.0,
    "associate":       8.0,
    "practitioner":    6.0,
    "foundation":      5.0,
    "certified":       4.0,
}


def score_certifications(certifications: list[str], max_score: float = 100.0) -> float:
    """
    Score certifications based on industry relevance and tier.
    Caps at max_score to avoid inflation.
    """
    if not certifications:
        return 0.0

    total = 0.0
    for cert in certifications:
        cert_lower = cert.lower()
        cert_score = 3.0  # baseline for any certification
        for keyword, bonus in _CERT_TIER.items():
            if keyword in cert_lower:
                cert_score = max(cert_score, bonus)
        total += cert_score

    return clamp(total, 0.0, max_score)


# ── Project Scoring ───────────────────────────────────────────────────────────

_PROJECT_KEYWORDS = {
    "ai":           8.0,
    "ml":           8.0,
    "machine learning": 8.0,
    "deep learning": 8.0,
    "nlp":          7.0,
    "blockchain":   7.0,
    "distributed":  7.0,
    "microservice": 7.0,
    "real-time":    6.0,
    "cloud":        6.0,
    "e-commerce":   5.0,
    "api":          4.0,
    "backend":      4.0,
    "full stack":   5.0,
    "mobile":       5.0,
    "parser":       3.0,
    "scraper":      3.0,
    "dashboard":    4.0,
    "analytics":    5.0,
    "recommendation": 6.0,
}


def score_projects(projects: list[str]) -> float:
    """
    Score the candidate's project list based on complexity signals
    embedded in project titles/descriptions.  Caps at 100.
    """
    if not projects:
        return 0.0

    base = min(len(projects) * 12.0, 60.0)   # up to 60 pts for quantity
    bonus = 0.0
    for project in projects:
        proj_lower = project.lower()
        for kw, pts in _PROJECT_KEYWORDS.items():
            if kw in proj_lower:
                bonus += pts
                break   # one bonus per project

    return clamp(base + bonus)


# ── Experience Scoring ────────────────────────────────────────────────────────

def score_experience(
    candidate_exp: float,
    required_exp: float,
) -> tuple[float, str, float]:
    """
    Calculate experience score and determine qualification status.

    Returns:
        (score 0-100, status_label, gap_years)
    """
    gap = candidate_exp - required_exp

    if required_exp == 0:
        # No experience required → any experience is a bonus
        score = min(100.0, 70.0 + candidate_exp * 5.0)
        return clamp(score), "Experienced", 0.0

    if gap == 0:
        return 100.0, "Exact Match", 0.0
    elif gap > 0:
        # Overqualified — small penalty after +5 years excess
        overqualification_penalty = max(0.0, (gap - 5) * 3.0)
        score = clamp(100.0 - overqualification_penalty)
        return score, "Overqualified", gap
    else:
        # Underqualified — proportional deduction
        shortfall_ratio = abs(gap) / required_exp
        score = clamp(100.0 * (1.0 - shortfall_ratio))
        return score, "Underqualified", gap


# ── Confidence Score ──────────────────────────────────────────────────────────

def calculate_confidence(
    skill_match_pct: float,
    fraud_risk_score: float,
    data_completeness: float,
) -> float:
    """
    Estimate AI confidence in the produced ranking.
    High skill match + low fraud risk + complete data → high confidence.
    """
    confidence = (
        skill_match_pct * 0.5
        + (100.0 - fraud_risk_score) * 0.3
        + data_completeness * 0.2
    )
    return clamp(confidence)


def calculate_data_completeness(candidate_dict: dict) -> float:
    """Score how complete the submitted candidate profile is (0-100)."""
    fields = {
        "name": 10,
        "skills": 25,
        "experience": 20,
        "education": 15,
        "projects": 15,
        "certifications": 10,
        "summary": 5,
    }
    score = 0.0
    for field, weight in fields.items():
        val = candidate_dict.get(field)
        if val is not None and val != "" and val != []:
            score += weight
    return score
