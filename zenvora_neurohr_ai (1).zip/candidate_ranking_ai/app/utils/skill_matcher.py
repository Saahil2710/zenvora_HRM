"""
Module  : utils/skill_matcher.py
Purpose : Smart skill matching engine.
          - Exact matching (case-insensitive)
          - Related-skill detection via knowledge graph
          - spaCy semantic similarity (optional, gracefully degraded)
          - Skill category detection
          - Domain detection
"""

from __future__ import annotations

import logging
from typing import Optional

from app.data.skill_knowledge_base import (
    SKILL_RELATIONS,
    SKILL_CATEGORIES,
    DOMAIN_SKILL_MAP,
)
from app.core.logger import setup_logger

logger = setup_logger(__name__)

# ── spaCy graceful loading ────────────────────────────────────────────────────
try:
    import spacy
    _nlp = spacy.load("en_core_web_sm")
    _SPACY_AVAILABLE = True
    logger.info("spaCy model loaded: en_core_web_sm")
except Exception as exc:
    _SPACY_AVAILABLE = False
    _nlp = None
    logger.warning(f"spaCy unavailable ({exc}). Falling back to lexical matching.")


# ═══════════════════════════════════════════════════════════════════════════════
#  Core Matching Logic
# ═══════════════════════════════════════════════════════════════════════════════

def normalise(skill: str) -> str:
    """Lowercase + strip for consistent comparison."""
    return skill.lower().strip()


def exact_match(candidate_skills: list[str], required_skills: list[str]) -> list[str]:
    """Return skills present in both lists (case-insensitive)."""
    cand_norm = {normalise(s) for s in candidate_skills}
    return [s for s in required_skills if normalise(s) in cand_norm]


def find_related_skills(
    candidate_skills: list[str],
    required_skills: list[str],
    already_matched: list[str],
) -> list[str]:
    """
    Detect required skills that the candidate likely has via related skills.
    Returns human-readable strings like "React → JavaScript".
    """
    cand_norm = {normalise(s) for s in candidate_skills}
    matched_norm = {normalise(s) for s in already_matched}
    related: list[str] = []

    for req in required_skills:
        req_norm = normalise(req)
        if req_norm in matched_norm:
            continue  # already directly matched

        # Check if candidate has a skill that implies req
        for cand in candidate_skills:
            cand_n = normalise(cand)
            # Does cand_n have req_norm as a related skill?
            if req_norm in [normalise(r) for r in SKILL_RELATIONS.get(cand_n, [])]:
                related.append(f"{cand} → {req}")
                matched_norm.add(req_norm)
                break

    return related


def semantic_skill_similarity(skill_a: str, skill_b: str) -> Optional[float]:
    """
    Return spaCy cosine similarity between two skill strings.
    Returns None if spaCy is unavailable.
    """
    if not _SPACY_AVAILABLE or _nlp is None:
        return None
    doc_a = _nlp(skill_a.lower())
    doc_b = _nlp(skill_b.lower())
    if doc_a.has_vector and doc_b.has_vector:
        return doc_a.similarity(doc_b)
    return None


def find_semantically_similar_skills(
    candidate_skills: list[str],
    required_skills: list[str],
    already_matched_norm: set[str],
    threshold: float = 0.75,
) -> list[str]:
    """
    Use spaCy similarity to detect partially matching skills.
    Only runs when spaCy is available.
    Returns partial-match strings like "Pandas ~≈ NumPy".
    """
    if not _SPACY_AVAILABLE:
        return []

    partial: list[str] = []
    for req in required_skills:
        req_n = normalise(req)
        if req_n in already_matched_norm:
            continue
        for cand in candidate_skills:
            sim = semantic_skill_similarity(cand, req)
            if sim is not None and sim >= threshold:
                partial.append(f"{cand} ~≈ {req} ({sim:.0%})")
                already_matched_norm.add(req_n)
                break
    return partial


# ═══════════════════════════════════════════════════════════════════════════════
#  Full Skill Analysis
# ═══════════════════════════════════════════════════════════════════════════════

def analyse_skills(
    candidate_skills: list[str],
    required_skills: list[str],
    nice_to_have: list[str] | None = None,
) -> dict:
    """
    Comprehensive skill analysis pipeline.

    Returns a dict compatible with SkillAnalysis schema.
    """
    nice_to_have = nice_to_have or []

    # 1. Exact matches
    matched = exact_match(candidate_skills, required_skills)
    matched_norm = {normalise(s) for s in matched}

    # 2. Related-skill detection
    related = find_related_skills(candidate_skills, required_skills, matched)
    # Add related matches to the matched set for gap calculation
    related_req_skills = {normalise(r.split("→")[-1].strip()) for r in related}
    all_satisfied_norm = matched_norm | related_req_skills

    # 3. Semantic partial matching
    semantic_matches = find_semantically_similar_skills(
        candidate_skills, required_skills, all_satisfied_norm.copy()
    )
    semantic_req_norm = set()
    for sm in semantic_matches:
        # extract the required skill part after "~≈"
        parts = sm.split("~≈")
        if len(parts) == 2:
            req_part = parts[1].split("(")[0].strip()
            semantic_req_norm.add(normalise(req_part))
    all_satisfied_norm |= semantic_req_norm

    # 4. Missing skills
    missing = [s for s in required_skills if normalise(s) not in all_satisfied_norm]

    # 5. Nice-to-have matches
    nih_matched = exact_match(candidate_skills, nice_to_have)

    # 6. Skill match percentage
    total_required = len(required_skills)
    satisfied_count = len(all_satisfied_norm & {normalise(s) for s in required_skills})
    match_pct = (satisfied_count / total_required * 100.0) if total_required > 0 else 100.0

    return {
        "matched_skills": matched,
        "related_skills_detected": related + semantic_matches,
        "missing_skills": missing,
        "nice_to_have_matched": nih_matched,
        "skill_match_percentage": round(match_pct, 2),
    }


def skill_score_from_analysis(analysis: dict) -> float:
    """
    Compute a 0-100 skill score from the analysis dict.
    - Exact matches contribute 100% of their weight
    - Related/semantic matches contribute 70%
    - Nice-to-have matches add a small bonus
    """
    match_pct = analysis["skill_match_percentage"]
    related_bonus = len(analysis["related_skills_detected"]) * 2.0
    nih_bonus = len(analysis["nice_to_have_matched"]) * 1.5
    return min(100.0, match_pct + related_bonus + nih_bonus)


# ═══════════════════════════════════════════════════════════════════════════════
#  Skill Category & Domain Detection
# ═══════════════════════════════════════════════════════════════════════════════

def detect_skill_categories(skills: list[str]) -> dict[str, list[str]]:
    """
    Group the candidate's skills into known categories.
    Returns only categories that have at least one match.
    """
    cand_norm = {normalise(s) for s in skills}
    detected: dict[str, list[str]] = {}

    for category, cat_skills in SKILL_CATEGORIES.items():
        matches = [s for s in cat_skills if s in cand_norm]
        if matches:
            detected[category] = matches

    return detected


def detect_domain(skills: list[str], job_role: str = "") -> str:
    """
    Infer the candidate's domain from skills and job role.
    Returns the best-matching domain name.
    """
    cand_norm = {normalise(s) for s in skills}
    role_lower = job_role.lower()
    scores: dict[str, int] = {}

    for domain, domain_skills in DOMAIN_SKILL_MAP.items():
        score = sum(1 for ds in domain_skills if normalise(ds) in cand_norm)
        # Bonus if domain name appears in job role
        if domain.lower() in role_lower:
            score += 3
        scores[domain] = score

    if not scores or max(scores.values()) == 0:
        return "General Software Engineering"

    return max(scores, key=lambda d: scores[d])
