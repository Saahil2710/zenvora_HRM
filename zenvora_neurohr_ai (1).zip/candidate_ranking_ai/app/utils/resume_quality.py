"""
Module  : utils/resume_quality.py
Purpose : Resume Strength Meter — evaluates the overall quality and
          completeness of a submitted resume profile.
"""

from __future__ import annotations


def analyse_resume_quality(
    skills: list[str],
    experience: float,
    education: str,
    projects: list[str],
    certifications: list[str],
    summary: str | None,
) -> dict:
    """
    Calculate a quality score and level for the candidate's resume.

    Returns a dict compatible with the ResumeQuality schema.
    """
    score = 0.0
    insights: list[str] = []

    # ── Skills (max 30 pts) ───────────────────────────────────────────────────
    skill_count = len(skills)
    if skill_count >= 8:
        score += 30
        insights.append(f"Well-rounded skill set ({skill_count} skills listed).")
    elif skill_count >= 4:
        score += 20
        insights.append("Adequate skill representation.")
    elif skill_count >= 1:
        score += 10
        insights.append("Skill list is thin — expand with supporting tools and technologies.")
    else:
        insights.append("⚠️ No skills listed. This is a critical gap.")

    # ── Projects (max 25 pts) ─────────────────────────────────────────────────
    proj_count = len(projects)
    if proj_count >= 4:
        score += 25
        insights.append(f"Strong project portfolio ({proj_count} projects).")
    elif proj_count >= 2:
        score += 18
        insights.append("Good project evidence.")
    elif proj_count == 1:
        score += 10
        insights.append("Only one project — adding more increases credibility.")
    else:
        insights.append("⚠️ No projects listed — this weakens the profile significantly.")

    # ── Experience (max 20 pts) ───────────────────────────────────────────────
    if experience >= 3:
        score += 20
        insights.append("Solid professional experience.")
    elif experience >= 1:
        score += 14
    elif experience > 0:
        score += 8
        insights.append("Limited experience — compensate with strong projects.")

    # ── Education (max 10 pts) ────────────────────────────────────────────────
    edu_lower = education.lower()
    if any(k in edu_lower for k in ["phd", "m.tech", "mca", "m.sc"]):
        score += 10
    elif any(k in edu_lower for k in ["b.tech", "b.e", "bca", "b.sc"]):
        score += 8
    elif "diploma" in edu_lower:
        score += 5
    else:
        score += 3

    # ── Certifications (max 10 pts) ───────────────────────────────────────────
    if len(certifications) >= 3:
        score += 10
        insights.append("Multiple certifications strengthen credibility.")
    elif certifications:
        score += 6
    else:
        insights.append("Adding certifications would improve profile strength.")

    # ── Summary (max 5 pts) ───────────────────────────────────────────────────
    if summary and len(summary.split()) >= 30:
        score += 5
        insights.append("Professional summary adds context and personality.")
    elif summary:
        score += 2
    else:
        insights.append("A professional summary is missing — it helps recruiters quickly assess fit.")

    # Resolve level
    quality_level = _resolve_quality_level(score)

    return {
        "quality_score": round(min(score, 100.0), 2),
        "quality_level": quality_level,
        "quality_insights": insights[:6],
    }


def _resolve_quality_level(score: float) -> str:
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Average"
    return "Poor"
