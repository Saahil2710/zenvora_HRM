"""
Module  : utils/fraud_detector.py
Purpose : Heuristic fraud detection engine.
          Analyses resume signals for suspicious patterns including:
          - Unrealistic experience claims
          - Keyword stuffing
          - Duplicate / near-duplicate skills
          - Implausible certification combos
          - Age-experience inconsistencies
"""

from __future__ import annotations

from app.core.config import settings
from app.core.logger import setup_logger

logger = setup_logger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
#  Individual Fraud Checks
# ═══════════════════════════════════════════════════════════════════════════════

def check_experience_plausibility(
    experience: float,
) -> tuple[float, str | None]:
    """
    Detect unrealistically high experience claims.
    Returns (risk_delta, warning_message | None).
    """
    max_realistic = settings.MAX_REALISTIC_EXPERIENCE_YEARS

    if experience > max_realistic:
        return 40.0, (
            f"Claimed experience ({experience} years) exceeds realistic maximum ({max_realistic})."
        )
    if experience > 35:
        return 15.0, f"Very high experience claimed ({experience} years) — verify with references."
    return 0.0, None


def check_skill_duplication(skills: list[str]) -> tuple[float, str | None]:
    """
    Detect exact or near-duplicate skill entries (case / spacing variants).
    Returns (risk_delta, warning | None).
    """
    normalised = [s.lower().strip() for s in skills]
    seen: set[str] = set()
    duplicates: list[str] = []

    for s in normalised:
        if s in seen:
            duplicates.append(s)
        seen.add(s)

    if duplicates:
        return 15.0, f"Duplicate skills detected: {', '.join(set(duplicates))}."
    return 0.0, None


def check_keyword_stuffing(skills: list[str]) -> tuple[float, str | None]:
    """
    Detect suspiciously large skill lists that suggest padding.
    Returns (risk_delta, warning | None).
    """
    count = len(skills)
    if count > 40:
        return 30.0, f"Excessive skill count ({count}) suggests keyword stuffing."
    if count > 25:
        return 10.0, f"Large skill list ({count} skills) — consider validation in interview."
    return 0.0, None


def check_skill_coherence(
    skills: list[str],
    experience: float,
) -> tuple[float, str | None]:
    """
    Detect skill sets that are implausibly broad for the stated experience.
    E.g., 10+ distinct specialised areas claimed with <2 years of experience.
    """
    from app.utils.skill_matcher import detect_skill_categories

    categories = detect_skill_categories(skills)
    distinct_categories = len(categories)

    if experience < 2 and distinct_categories >= 6:
        return 20.0, (
            f"Claimed expertise in {distinct_categories} distinct domains with only "
            f"{experience:.1f} years of experience appears implausible."
        )
    return 0.0, None


def check_project_experience_ratio(
    projects: list[str],
    experience: float,
) -> tuple[float, str | None]:
    """
    Flag cases where projects significantly outnumber plausible delivery capacity.
    """
    if experience < 1 and len(projects) > 10:
        return 10.0, (
            f"{len(projects)} projects listed with only {experience:.1f} years experience — "
            "verify authenticity."
        )
    return 0.0, None


def check_certification_plausibility(
    certifications: list[str],
    experience: float,
) -> tuple[float, str | None]:
    """
    Detect unlikely accumulation of expensive/time-consuming certifications
    with very low experience.
    """
    if experience < 0.5 and len(certifications) >= 5:
        return 15.0, (
            f"{len(certifications)} certifications with less than 6 months experience "
            "is statistically unusual."
        )
    return 0.0, None


# ═══════════════════════════════════════════════════════════════════════════════
#  Aggregated Fraud Analysis
# ═══════════════════════════════════════════════════════════════════════════════

def analyse_fraud(
    skills: list[str],
    experience: float,
    projects: list[str],
    certifications: list[str],
) -> dict:
    """
    Run all heuristic checks and aggregate results into a fraud analysis dict.

    Returns a dict compatible with FraudAnalysis schema.
    """
    total_risk = 0.0
    warnings: list[str] = []
    detailed_flags: list[dict] = []

    checks = [
        ("experience_plausibility",    check_experience_plausibility(experience)),
        ("skill_duplication",          check_skill_duplication(skills)),
        ("keyword_stuffing",           check_keyword_stuffing(skills)),
        ("skill_coherence",            check_skill_coherence(skills, experience)),
        ("project_experience_ratio",   check_project_experience_ratio(projects, experience)),
        ("certification_plausibility", check_certification_plausibility(certifications, experience)),
    ]

    for check_name, (risk_delta, warning) in checks:
        if risk_delta > 0 and warning:
            total_risk += risk_delta
            warnings.append(warning)
            detailed_flags.append({
                "check": check_name,
                "risk_contribution": risk_delta,
                "flag": warning,
                "severity": _risk_severity(risk_delta),
            })

    risk_score = min(total_risk, 100.0)

    # Resolve level
    if risk_score >= settings.FRAUD_HIGH_RISK_THRESHOLD:
        level = "High"
    elif risk_score >= settings.FRAUD_MEDIUM_RISK_THRESHOLD:
        level = "Medium"
    else:
        level = "Low"

    return {
        "fraud_risk_score": round(risk_score, 2),
        "fraud_risk_level": level,
        "fraud_warnings":   warnings,
        "is_suspicious":    risk_score >= settings.FRAUD_MEDIUM_RISK_THRESHOLD,
        "_detailed_flags":  detailed_flags,   # private key for the fraud endpoint
    }


def _risk_severity(delta: float) -> str:
    if delta >= 30:
        return "Critical"
    if delta >= 15:
        return "High"
    if delta >= 5:
        return "Medium"
    return "Low"
