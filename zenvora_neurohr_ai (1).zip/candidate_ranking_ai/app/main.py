"""
╔══════════════════════════════════════════════════════════════════╗
║           Zenvora NeuroHR AI — Candidate Ranking Engine          ║
║           Enterprise AI-Powered Recruitment Intelligence         ║
╚══════════════════════════════════════════════════════════════════╝

Author  : Zenvora NeuroHR AI Team
Version : 2.0.0
Module  : Application Entry Point
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import time
import logging

from app.routers import ranking, fraud, health
from app.core.config import settings
from app.core.logger import setup_logger

# ── Logging ──────────────────────────────────────────────────────────────────
logger = setup_logger(__name__)

# ── FastAPI Application ───────────────────────────────────────────────────────
app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "🧠 **Zenvora NeuroHR AI** — Enterprise Candidate Ranking & Intelligence Engine\n\n"
        "An AI-powered recruitment system that provides explainable scoring, "
        "fraud detection, skill-gap analysis, and adaptive ranking for modern HR teams."
    ),
    version=settings.VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    contact={
        "name": "Zenvora NeuroHR AI",
        "url": "https://zenvora.ai",
        "email": "ai@zenvora.ai",
    },
    license_info={"name": "Proprietary"},
)

# ── CORS Middleware ───────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request Timing Middleware ─────────────────────────────────────────────────
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Attach X-Process-Time to every response for latency monitoring."""
    start = time.perf_counter()
    response = await call_next(request)
    elapsed = round((time.perf_counter() - start) * 1000, 2)
    response.headers["X-Process-Time"] = f"{elapsed}ms"
    logger.debug(f"{request.method} {request.url.path} — {elapsed}ms")
    return response


# ── Global Exception Handler ──────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception on {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "Internal Server Error",
            "message": str(exc),
            "path": str(request.url.path),
        },
    )


# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(health.router, tags=["System"])
app.include_router(ranking.router, prefix="/api/v1", tags=["Ranking Engine"])
app.include_router(fraud.router,   prefix="/api/v1", tags=["Fraud Detection"])


# ── Root ──────────────────────────────────────────────────────────────────────
@app.get("/", include_in_schema=False)
async def root():
    return {
        "system":  settings.APP_NAME,
        "version": settings.VERSION,
        "status":  "operational",
        "docs":    "/docs",
        "tagline": "AI-Powered Recruitment Intelligence at Enterprise Scale",
    }
