"""
Module  : core/config.py
Purpose : Centralised application settings via Pydantic BaseSettings.
          All values can be overridden via environment variables or .env file.
"""

from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # ── Identity ──────────────────────────────────────────────────────────────
    APP_NAME: str = "Zenvora NeuroHR AI — Candidate Ranking Engine"
    VERSION: str  = "2.0.0"
    DEBUG: bool   = False

    # ── Security / CORS ───────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = ["*"]   # tighten in production
    SECRET_KEY: str = "zenvora-neurohr-secret-change-in-production"

    # ── Default Scoring Weights (must sum to 100) ─────────────────────────────
    DEFAULT_SKILLS_WEIGHT: float      = 50.0
    DEFAULT_EXPERIENCE_WEIGHT: float  = 25.0
    DEFAULT_PROJECTS_WEIGHT: float    = 10.0
    DEFAULT_EDUCATION_WEIGHT: float   = 10.0
    DEFAULT_CERTS_WEIGHT: float       =  5.0

    # ── Fraud Detection Thresholds ────────────────────────────────────────────
    FRAUD_HIGH_RISK_THRESHOLD: float  = 70.0
    FRAUD_MEDIUM_RISK_THRESHOLD: float = 40.0
    MAX_REALISTIC_EXPERIENCE_YEARS: int = 45

    # ── NLP ───────────────────────────────────────────────────────────────────
    SPACY_MODEL: str = "en_core_web_sm"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
