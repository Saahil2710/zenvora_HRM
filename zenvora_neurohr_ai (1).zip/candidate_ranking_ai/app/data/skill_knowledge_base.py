"""
Module  : data/skill_knowledge_base.py
Purpose : Static knowledge base for skill relationships, categories, domains,
          and education tiers.  No external DB required — pure Python dicts.
"""

# ── Skill Relationship Graph ──────────────────────────────────────────────────
# Maps a "child" skill to its parent / related skills.
# If a candidate has the child, they likely know the parent too.

SKILL_RELATIONS: dict[str, list[str]] = {
    # JavaScript ecosystem
    "react":          ["javascript", "html", "css"],
    "next.js":        ["react", "javascript", "node.js"],
    "vue":            ["javascript", "html", "css"],
    "nuxt":           ["vue", "javascript"],
    "angular":        ["typescript", "javascript"],
    "typescript":     ["javascript"],
    "node.js":        ["javascript"],
    "express":        ["node.js", "javascript"],
    "nestjs":         ["node.js", "typescript"],

    # Python ecosystem
    "fastapi":        ["python", "pydantic"],
    "django":         ["python"],
    "flask":          ["python"],
    "celery":         ["python", "redis"],
    "sqlalchemy":     ["python", "sql"],
    "pandas":         ["python", "numpy"],
    "tensorflow":     ["python", "numpy"],
    "pytorch":        ["python", "numpy"],
    "scikit-learn":   ["python", "numpy", "pandas"],
    "keras":          ["tensorflow", "python"],

    # Java ecosystem
    "spring boot":    ["java", "spring"],
    "spring":         ["java"],
    "hibernate":      ["java", "sql"],
    "maven":          ["java"],
    "gradle":         ["java"],
    "kotlin":         ["java"],

    # .NET ecosystem
    "asp.net":        ["c#", ".net"],
    "entity framework": ["c#", ".net", "sql"],
    "blazor":         ["c#", ".net"],

    # DevOps / Cloud
    "kubernetes":     ["docker", "linux"],
    "helm":           ["kubernetes"],
    "terraform":      ["aws", "devops"],
    "ansible":        ["linux", "devops"],
    "jenkins":        ["ci/cd", "devops"],
    "github actions": ["git", "ci/cd"],
    "argocd":         ["kubernetes", "devops"],
    "aws lambda":     ["aws", "serverless"],
    "aws":            ["cloud"],
    "gcp":            ["cloud"],
    "azure":          ["cloud"],

    # Databases
    "postgresql":     ["sql"],
    "mysql":          ["sql"],
    "sqlite":         ["sql"],
    "mongodb":        ["nosql"],
    "redis":          ["nosql", "caching"],
    "elasticsearch":  ["nosql"],
    "cassandra":      ["nosql"],

    # Data / ML
    "spark":          ["big data", "python"],
    "hadoop":         ["big data"],
    "airflow":        ["python", "data engineering"],
    "dbt":            ["sql", "data engineering"],
    "tableau":        ["data visualization"],
    "power bi":       ["data visualization"],

    # Mobile
    "react native":   ["react", "javascript"],
    "flutter":        ["dart"],
    "swift":          ["ios"],
    "kotlin android": ["kotlin", "android"],

    # General
    "graphql":        ["api"],
    "rest api":       ["api", "http"],
    "grpc":           ["api"],
    "microservices":  ["distributed systems"],
}


# ── Skill Category Map ────────────────────────────────────────────────────────

SKILL_CATEGORIES: dict[str, list[str]] = {
    "Frontend": [
        "react", "next.js", "vue", "nuxt", "angular", "html", "css",
        "sass", "tailwind", "bootstrap", "webpack", "vite", "typescript",
    ],
    "Backend": [
        "python", "fastapi", "django", "flask", "node.js", "express",
        "nestjs", "java", "spring boot", "spring", "ruby on rails",
        "php", "laravel", "go", "rust", "c#", "asp.net",
    ],
    "Database": [
        "sql", "postgresql", "mysql", "sqlite", "mongodb", "redis",
        "elasticsearch", "cassandra", "dynamodb", "firebase",
    ],
    "DevOps & Cloud": [
        "docker", "kubernetes", "aws", "gcp", "azure", "terraform",
        "ansible", "jenkins", "github actions", "ci/cd", "linux",
        "nginx", "argocd", "helm",
    ],
    "Data Science & ML": [
        "python", "pandas", "numpy", "tensorflow", "pytorch",
        "scikit-learn", "keras", "spark", "hadoop", "airflow",
        "dbt", "tableau", "power bi", "r", "matlab",
    ],
    "Mobile": [
        "react native", "flutter", "swift", "kotlin android",
        "android", "ios", "dart",
    ],
    "Security": [
        "owasp", "penetration testing", "siem", "iam", "jwt",
        "oauth", "ssl/tls", "firewall",
    ],
    "API & Architecture": [
        "rest api", "graphql", "grpc", "microservices",
        "distributed systems", "event-driven", "kafka", "rabbitmq",
    ],
}


# ── Domain Detection Map ──────────────────────────────────────────────────────

DOMAIN_SKILL_MAP: dict[str, list[str]] = {
    "FinTech":           ["payment", "blockchain", "stripe", "plaid", "ledger"],
    "HealthTech":        ["hl7", "fhir", "dicom", "ehr", "medical", "healthcare"],
    "AI/ML Engineering": ["tensorflow", "pytorch", "scikit-learn", "nlp", "llm", "langchain"],
    "Data Engineering":  ["spark", "hadoop", "airflow", "dbt", "kafka", "data warehouse"],
    "DevOps/SRE":        ["kubernetes", "terraform", "ansible", "ci/cd", "sre", "monitoring"],
    "Cybersecurity":     ["penetration testing", "owasp", "siem", "cve", "ctf"],
    "Full Stack":        ["react", "node.js", "sql", "docker"],
    "Backend":           ["python", "java", "go", "fastapi", "spring boot"],
    "Frontend":          ["react", "vue", "angular", "html", "css"],
    "Mobile":            ["flutter", "react native", "swift", "android"],
}


# ── Education Tier Scoring ────────────────────────────────────────────────────

EDUCATION_SCORE_MAP: dict[str, float] = {
    "phd":      100.0,
    "m.tech":   88.0,
    "m.sc":     85.0,
    "mba":      80.0,
    "mca":      80.0,
    "m.e":      88.0,
    "b.tech":   75.0,
    "b.e":      75.0,
    "b.sc":     65.0,
    "bca":      65.0,
    "bba":      55.0,
    "diploma":  45.0,
    "12th":     30.0,
    "10th":     20.0,
}

DEFAULT_EDUCATION_SCORE: float = 50.0


# ── Ranking Level Thresholds ──────────────────────────────────────────────────

RANKING_LEVELS: list[tuple[float, str]] = [
    (90.0, "Excellent"),
    (75.0, "Good"),
    (60.0, "Average"),
    (45.0, "Below Average"),
    (  0.0, "Poor"),
]


# ── Hiring Recommendation Thresholds ─────────────────────────────────────────

HIRING_RECOMMENDATIONS: list[tuple[float, str]] = [
    (85.0, "Strongly Recommend"),
    (70.0, "Recommend"),
    (55.0, "Consider"),
    (  0.0, "Not Recommended"),
]
