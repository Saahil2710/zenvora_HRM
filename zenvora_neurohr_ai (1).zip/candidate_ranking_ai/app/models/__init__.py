"""
app/models/
-----------
Reserved for ORM models if a database layer (SQLAlchemy / Beanie) is added.
Currently, all data contracts are handled by Pydantic schemas in app/schemas/.
"""
