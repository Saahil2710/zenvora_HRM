"""
Module  : routers/fraud.py
Purpose : FastAPI router for fraud detection endpoint.

Endpoint:
  POST  /fraud-check
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status

from app.schemas.ranking_schema import FraudCheckRequest, FraudCheckResponse
from app.services.fraud_service import check_candidate_fraud
from app.core.logger import setup_logger

router = APIRouter()
logger = setup_logger(__name__)


@router.post(
    "/fraud-check",
    response_model=FraudCheckResponse,
    status_code=status.HTTP_200_OK,
    summary="Fraud Risk Detection",
    description=(
        "Run heuristic fraud detection on a candidate resume. "
        "Analyses experience plausibility, keyword stuffing, skill coherence, "
        "and certification claims."
    ),
)
async def fraud_check(payload: FraudCheckRequest):
    """
    **Zenvora NeuroHR — Fraud Detection**

    Applies multi-heuristic analysis to identify suspicious resume patterns.
    Returns a fraud risk score (0–100), risk level, and detailed flag breakdown.
    """
    try:
        result = await check_candidate_fraud(candidate=payload.candidate)
        return result
    except Exception as exc:
        logger.error(f"fraud_check failed: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Fraud detection error: {exc}")
