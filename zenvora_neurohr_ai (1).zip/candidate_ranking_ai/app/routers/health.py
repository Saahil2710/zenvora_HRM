"""
Module  : routers/health.py
Purpose : System health check endpoint for load balancers, k8s probes, and monitoring.
"""

from __future__ import annotations

import sys
import platform
from datetime import datetime, timezone

from fastapi import APIRouter
from pydantic import BaseModel

from app.core.config import settings

router = APIRouter()

_START_TIME = datetime.now(timezone.utc)


class HealthResponse(BaseModel):
    status: str
    system: str
    version: str
    uptime_seconds: float
    python_version: str
    platform: str
    timestamp: str


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="System Health Check",
    tags=["System"],
)
async def health_check():
    """
    Lightweight health probe.
    Returns 200 when the service is operational.
    Suitable for Kubernetes liveness/readiness probes.
    """
    now = datetime.now(timezone.utc)
    uptime = (now - _START_TIME).total_seconds()

    return HealthResponse(
        status="operational",
        system=settings.APP_NAME,
        version=settings.VERSION,
        uptime_seconds=round(uptime, 2),
        python_version=sys.version.split()[0],
        platform=platform.system(),
        timestamp=now.isoformat(),
    )
