"""
Module  : routers/ranking.py
Purpose : FastAPI router for all ranking-related endpoints.

Endpoints:
  POST  /rank-candidate
  POST  /rank-multiple-candidates
  POST  /analyze-job-match
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import JSONResponse

from app.schemas.ranking_schema import (
    RankCandidateRequest,
    RankMultipleCandidatesRequest,
    JobMatchRequest,
    CandidateRankingResult,
    RankMultipleResponse,
    JobMatchResponse,
)
from app.services.ranking_service import (
    rank_single_candidate,
    rank_multiple_candidates,
    analyse_job_match,
)
from app.core.logger import setup_logger

router = APIRouter()
logger = setup_logger(__name__)


# ── POST /rank-candidate ──────────────────────────────────────────────────────

@router.post(
    "/rank-candidate",
    response_model=CandidateRankingResult,
    status_code=status.HTTP_200_OK,
    summary="Rank a Single Candidate",
    description=(
        "Analyse and rank one candidate profile against a job description. "
        "Returns an explainable AI score with strengths, weaknesses, skill analysis, "
        "fraud risk, and hiring recommendation."
    ),
)
async def rank_candidate(payload: RankCandidateRequest):
    """
    **Zenvora NeuroHR — Single Candidate Ranking**

    Supply a parsed candidate profile, a job description, and optional
    adaptive weights. The engine returns a full explainable ranking.
    """
    try:
        result = await rank_single_candidate(
            candidate=payload.candidate,
            job=payload.job,
            weights=payload.weights,
        )
        return result
    except ValueError as ve:
        logger.warning(f"Validation error in rank_candidate: {ve}")
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as exc:
        logger.error(f"rank_candidate failed: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Ranking engine error: {exc}")


# ── POST /rank-multiple-candidates ────────────────────────────────────────────

@router.post(
    "/rank-multiple-candidates",
    response_model=RankMultipleResponse,
    status_code=status.HTTP_200_OK,
    summary="Rank Multiple Candidates (Batch)",
    description=(
        "Batch-rank up to 50 candidates against a single job description. "
        "Returns sorted rankings with summary analytics."
    ),
)
async def rank_multiple(payload: RankMultipleCandidatesRequest):
    """
    **Zenvora NeuroHR — Batch Candidate Ranking**

    Accepts up to 50 candidates in one request. Returns top-N sorted by score,
    with a statistical summary across the full cohort.
    """
    try:
        result = await rank_multiple_candidates(
            candidates=payload.candidates,
            job=payload.job,
            weights=payload.weights,
            top_n=payload.top_n,
        )
        return result
    except ValueError as ve:
        logger.warning(f"Validation error in rank_multiple: {ve}")
        raise HTTPException(status_code=422, detail=str(ve))
    except Exception as exc:
        logger.error(f"rank_multiple failed: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch ranking engine error: {exc}")


# ── POST /analyze-job-match ───────────────────────────────────────────────────

@router.post(
    "/analyze-job-match",
    response_model=JobMatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Analyse Job Compatibility",
    description=(
        "Deep-dive compatibility analysis between a candidate and a job description. "
        "Returns skill gap analysis, action items, and a hiring recommendation."
    ),
)
async def analyze_job_match(payload: JobMatchRequest):
    """
    **Zenvora NeuroHR — Job Match Analyser**

    Provides a focused compatibility deep-dive without the full ranking pipeline.
    Ideal for quick pre-screening assessments.
    """
    try:
        result = await analyse_job_match(
            candidate=payload.candidate,
            job=payload.job,
        )
        return result
    except Exception as exc:
        logger.error(f"analyze_job_match failed: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Job match analysis error: {exc}")
