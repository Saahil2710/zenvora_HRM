# 🧠 Zenvora NeuroHR AI — Candidate Ranking Engine

> **Enterprise AI-Powered Recruitment Intelligence**
> Python 3.11 · FastAPI · spaCy · scikit-learn · Pydantic v2

[![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![spaCy](https://img.shields.io/badge/spaCy-3.7-09A3D5?logo=spacy&logoColor=white)](https://spacy.io)
[![Code Style](https://img.shields.io/badge/code%20style-clean%20architecture-brightgreen)](.)

---

## 📌 Overview

**Zenvora NeuroHR AI** is the AI Candidate Ranking module of the Zenvora HR Platform. It receives pre-parsed resume data from the MERN frontend team and returns comprehensive, explainable AI-driven rankings.

This is **not** a keyword matcher — it is a full multi-signal intelligence engine with:

| Feature | Description |
|---|---|
| 🎯 Weighted Scoring | Configurable per-dimension weights (skills, experience, education, projects, certs) |
| 🔗 Smart Skill Matching | Exact + related-skill detection via knowledge graph + spaCy NLP |
| 🕵️ Fraud Detection | 6-heuristic suspicious-resume analyser |
| 🤖 Explainable AI | Natural language strengths, weaknesses, insights per candidate |
| ⚖️ Adaptive Engine | Recruiters change weights per job posting — engine auto-adapts |
| 📊 Batch Ranking | Rank up to 50 candidates in one request with summary analytics |
| 🏷️ Smart Tags | Auto-generated candidate labels (Top Candidate, Backend Specialist…) |
| 🎓 Resume Quality Meter | Multi-dimensional resume strength score |
| 🌐 Domain Detection | Detects FinTech / HealthTech / DevOps / AI domains automatically |

---

## 🗂️ Project Structure

```
candidate_ranking_ai/
│
├── app/
│   ├── main.py                        # FastAPI app, middleware, routers
│   │
│   ├── core/
│   │   ├── config.py                  # Pydantic Settings (env-driven config)
│   │   └── logger.py                  # Structured logging
│   │
│   ├── routers/
│   │   ├── ranking.py                 # /rank-candidate, /rank-multiple, /analyze-job-match
│   │   ├── fraud.py                   # /fraud-check
│   │   └── health.py                  # /health
│   │
│   ├── services/
│   │   ├── ranking_service.py         # Core orchestration pipeline
│   │   └── fraud_service.py           # Fraud detection service
│   │
│   ├── schemas/
│   │   └── ranking_schema.py          # All Pydantic request/response models
│   │
│   ├── utils/
│   │   ├── skill_matcher.py           # NLP + graph-based skill matching
│   │   ├── scoring_utils.py           # Pure scoring math utilities
│   │   ├── fraud_detector.py          # 6-heuristic fraud checks
│   │   ├── explainability.py          # Natural language AI explanations
│   │   └── resume_quality.py          # Resume strength meter
│   │
│   └── data/
│       └── skill_knowledge_base.py    # Skill relations, categories, domain map
│
├── requirements.txt
├── .env
└── README.md
```

---

## ⚡ Quick Start

### 1 — Clone & Enter Directory

```bash
git clone https://github.com/your-org/zenvora-neurohr-ai.git
cd zenvora-neurohr-ai/candidate_ranking_ai
```

### 2 — Create Virtual Environment

```bash
python -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 3 — Install Dependencies

```bash
pip install -r requirements.txt
```

### 4 — Download spaCy Language Model

```bash
python -m spacy download en_core_web_sm
```

### 5 — Configure Environment

```bash
cp .env.example .env
# Edit .env with your values if needed (defaults work out of the box)
```

### 6 — Run the Server

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The API is now live at:
- **Swagger UI** → http://localhost:8000/docs
- **ReDoc**       → http://localhost:8000/redoc
- **Health**      → http://localhost:8000/health

---

## 🔌 API Reference

### `GET /health`
System health check — returns uptime, version, platform info.

---

### `POST /api/v1/rank-candidate`
Rank a single candidate against a job description.

**Request Body:**
```json
{
  "candidate": {
    "name": "Rahul Sharma",
    "skills": ["Python", "FastAPI", "SQL", "React"],
    "experience": 2,
    "education": "B.Tech",
    "projects": ["AI Resume Parser", "E-commerce Backend"],
    "certifications": ["AWS Cloud Practitioner"],
    "summary": "Backend engineer with 2 years of experience in Python microservices."
  },
  "job": {
    "job_role": "Backend Developer",
    "required_skills": ["Python", "FastAPI", "Docker", "SQL"],
    "required_experience": 2,
    "nice_to_have_skills": ["Redis", "Kubernetes"]
  },
  "weights": {
    "skills_weight": 50,
    "experience_weight": 25,
    "projects_weight": 10,
    "education_weight": 10,
    "certs_weight": 5
  }
}
```

**Response (excerpt):**
```json
{
  "candidate_name": "Rahul Sharma",
  "job_role": "Backend Developer",
  "final_score": 88.4,
  "ranking_level": "Excellent",
  "confidence_score": 82.1,
  "score_breakdown": {
    "skills_score": 91.5,
    "experience_score": 100.0,
    "projects_score": 54.0,
    "education_score": 75.0,
    "certifications_score": 6.0,
    "weighted_total": 88.4
  },
  "skill_analysis": {
    "matched_skills": ["Python", "FastAPI", "SQL"],
    "related_skills_detected": ["React → JavaScript"],
    "missing_skills": ["Docker"],
    "nice_to_have_matched": [],
    "skill_match_percentage": 75.0
  },
  "experience_analysis": {
    "candidate_experience": 2.0,
    "required_experience": 2.0,
    "experience_score": 100.0,
    "experience_status": "Exact Match",
    "gap_years": 0.0
  },
  "strengths": [
    "Strong skill coverage (75% match) for the role.",
    "Demonstrated Backend expertise: python, fastapi.",
    "Experience level precisely matches the job requirement.",
    "Real-world project experience demonstrates practical application.",
    "Certified professional: AWS Cloud Practitioner."
  ],
  "weaknesses": [
    "Missing 1 required skill(s): Docker.",
    "No industry certifications listed — consider adding relevant credentials."
  ],
  "fraud_analysis": {
    "fraud_risk_score": 0.0,
    "fraud_risk_level": "Low",
    "fraud_warnings": [],
    "is_suspicious": false
  },
  "recommended_role": "Backend Developer",
  "candidate_tags": ["🌟 Top Candidate", "💻 Backend Specialist", "✔️ Right Fit"],
  "hiring_recommendation": "Strongly Recommend",
  "domain_detected": "Backend",
  "smart_insights": [
    "Composite AI score of 88.4/100 places this candidate in the top tier.",
    "1 adjacent skill(s) detected — candidate likely adaptable with short ramp-up.",
    "Domain alignment detected: Backend.",
    "Resume integrity check passed — profile appears authentic and consistent."
  ]
}
```

---

### `POST /api/v1/rank-multiple-candidates`
Batch rank up to 50 candidates.

**Request Body:**
```json
{
  "candidates": [
    {
      "name": "Priya Nair",
      "skills": ["Python", "Django", "PostgreSQL", "Docker"],
      "experience": 3,
      "education": "M.Tech",
      "projects": ["REST API Gateway", "Inventory System"],
      "certifications": ["GCP Associate"]
    },
    {
      "name": "Arjun Mehta",
      "skills": ["Java", "Spring Boot", "MySQL"],
      "experience": 1,
      "education": "B.Tech",
      "projects": ["Banking Portal"],
      "certifications": []
    }
  ],
  "job": {
    "job_role": "Backend Developer",
    "required_skills": ["Python", "FastAPI", "Docker", "SQL"],
    "required_experience": 2
  },
  "top_n": 5
}
```

**Response (excerpt):**
```json
{
  "job_role": "Backend Developer",
  "total_candidates": 2,
  "top_n_returned": 2,
  "ranked_candidates": [
    {
      "rank": 1,
      "candidate_name": "Priya Nair",
      "final_score": 82.3,
      "ranking_level": "Good",
      "hiring_recommendation": "Recommend",
      "candidate_tags": ["✅ Strong Candidate", "💻 Backend Specialist"],
      "missing_skills": ["FastAPI"],
      "fraud_risk_level": "Low"
    }
  ],
  "summary": {
    "average_score": 71.4,
    "highest_score": 82.3,
    "lowest_score": 60.5,
    "std_deviation": 10.9,
    "level_distribution": { "Good": 1, "Average": 1 },
    "strongly_recommended": 0,
    "suspicious_profiles": 0
  }
}
```

---

### `POST /api/v1/analyze-job-match`
Quick compatibility deep-dive — focused on skill gap and action items.

```json
{
  "candidate": { "name": "...", "skills": [...], "experience": 2, "education": "B.Tech", "projects": [], "certifications": [] },
  "job": { "job_role": "...", "required_skills": [...], "required_experience": 2 }
}
```

---

### `POST /api/v1/fraud-check`
Heuristic fraud analysis on a resume.

```json
{
  "candidate": {
    "name": "Suspicious Candidate",
    "skills": ["Python","Java","Go","Rust","C++","React","Angular","Vue","Swift","Kotlin","Django","FastAPI","Spring","Flask","Rails","Laravel","Node","Express","NestJS","GraphQL","Redis","Kafka","Spark","Terraform","Kubernetes"],
    "experience": 50,
    "education": "B.Tech",
    "projects": [],
    "certifications": ["AWS","GCP","Azure","CKA","CKAD","PMP","CISSP","CISA"]
  }
}
```

---

## 🧪 cURL Examples

### Rank a Single Candidate
```bash
curl -X POST http://localhost:8000/api/v1/rank-candidate \
  -H "Content-Type: application/json" \
  -d '{
    "candidate": {
      "name": "Rahul Sharma",
      "skills": ["Python", "FastAPI", "SQL", "React"],
      "experience": 2,
      "education": "B.Tech",
      "projects": ["AI Resume Parser", "E-commerce Backend"],
      "certifications": ["AWS Cloud Practitioner"]
    },
    "job": {
      "job_role": "Backend Developer",
      "required_skills": ["Python", "FastAPI", "Docker", "SQL"],
      "required_experience": 2
    }
  }'
```

### Health Check
```bash
curl http://localhost:8000/health
```

### Fraud Check
```bash
curl -X POST http://localhost:8000/api/v1/fraud-check \
  -H "Content-Type: application/json" \
  -d '{
    "candidate": {
      "name": "Test User",
      "skills": ["Python","Python","Python","Java","Go","Rust"],
      "experience": 60,
      "education": "B.Tech",
      "projects": [],
      "certifications": []
    }
  }'
```

### Adaptive Weights Example
```bash
curl -X POST http://localhost:8000/api/v1/rank-candidate \
  -H "Content-Type: application/json" \
  -d '{
    "candidate": { ... },
    "job": { ... },
    "weights": {
      "skills_weight": 60,
      "experience_weight": 20,
      "projects_weight": 10,
      "education_weight": 7,
      "certs_weight": 3
    }
  }'
```

---

## 🏗️ Architecture

```
MERN Backend (Parsed Resume Data)
            │
            ▼
    ┌───────────────────────────────────────────┐
    │          FastAPI Application              │
    │                                           │
    │  ┌─────────┐  ┌──────────┐  ┌─────────┐  │
    │  │ Routers │→ │ Services │→ │  Utils  │  │
    │  └─────────┘  └──────────┘  └─────────┘  │
    │                    │                      │
    │         ┌──────────┼──────────┐           │
    │         ▼          ▼          ▼           │
    │   SkillMatcher  Scorer  FraudDetector     │
    │         │          │          │           │
    │         └──────────┼──────────┘           │
    │                    ▼                      │
    │           Explainability Engine           │
    │                    │                      │
    │                    ▼                      │
    │          CandidateRankingResult           │
    └───────────────────────────────────────────┘
            │
            ▼
    HR Platform / Recruiter Dashboard
```

### Scoring Pipeline

```
Input Candidate + Job
        │
        ├──► Skill Matcher ──────────► Skill Score  (weight: 50%)
        │     ├─ Exact match
        │     ├─ Related-skill graph
        │     └─ spaCy NLP similarity
        │
        ├──► Experience Analyser ────► Exp Score    (weight: 25%)
        │     └─ Gap calculation
        │
        ├──► Project Scorer ─────────► Proj Score   (weight: 10%)
        │     └─ Complexity keywords
        │
        ├──► Education Scorer ───────► Edu Score    (weight: 10%)
        │     └─ Tier map
        │
        ├──► Cert Scorer ────────────► Cert Score   (weight:  5%)
        │
        └──► WEIGHTED SUM = Final Score
                    │
                    ├──► Ranking Level
                    ├──► Hiring Recommendation
                    ├──► Explainability Layer
                    ├──► Tags Generator
                    ├──► Fraud Analyser
                    └──► Resume Quality Meter
```

---

## 🔧 Configuration

All settings are in `.env` and override-able per environment:

| Variable | Default | Description |
|---|---|---|
| `DEFAULT_SKILLS_WEIGHT` | 50 | Default % weight for skills |
| `DEFAULT_EXPERIENCE_WEIGHT` | 25 | Default % weight for experience |
| `DEFAULT_PROJECTS_WEIGHT` | 10 | Default % weight for projects |
| `DEFAULT_EDUCATION_WEIGHT` | 10 | Default % weight for education |
| `DEFAULT_CERTS_WEIGHT` | 5 | Default % weight for certifications |
| `FRAUD_HIGH_RISK_THRESHOLD` | 70 | Score above = High fraud risk |
| `FRAUD_MEDIUM_RISK_THRESHOLD` | 40 | Score above = Medium fraud risk |
| `MAX_REALISTIC_EXPERIENCE_YEARS` | 45 | Clamp for experience plausibility |
| `SPACY_MODEL` | en_core_web_sm | spaCy model name |

---

## 📦 Postman Collection

Import this JSON into Postman:

```json
{
  "info": { "name": "Zenvora NeuroHR AI", "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json" },
  "item": [
    {
      "name": "Health Check",
      "request": { "method": "GET", "url": "http://localhost:8000/health" }
    },
    {
      "name": "Rank Single Candidate",
      "request": {
        "method": "POST",
        "url": "http://localhost:8000/api/v1/rank-candidate",
        "header": [{ "key": "Content-Type", "value": "application/json" }],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"candidate\": {\n    \"name\": \"Rahul Sharma\",\n    \"skills\": [\"Python\", \"FastAPI\", \"SQL\", \"React\"],\n    \"experience\": 2,\n    \"education\": \"B.Tech\",\n    \"projects\": [\"AI Resume Parser\", \"E-commerce Backend\"],\n    \"certifications\": [\"AWS Cloud Practitioner\"]\n  },\n  \"job\": {\n    \"job_role\": \"Backend Developer\",\n    \"required_skills\": [\"Python\", \"FastAPI\", \"Docker\", \"SQL\"],\n    \"required_experience\": 2\n  }\n}"
        }
      }
    },
    {
      "name": "Fraud Check",
      "request": {
        "method": "POST",
        "url": "http://localhost:8000/api/v1/fraud-check",
        "header": [{ "key": "Content-Type", "value": "application/json" }],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"candidate\": {\n    \"name\": \"Suspicious User\",\n    \"skills\": [\"Python\",\"Python\",\"Java\",\"Go\",\"Rust\"],\n    \"experience\": 60,\n    \"education\": \"B.Tech\",\n    \"projects\": [],\n    \"certifications\": []\n  }\n}"
        }
      }
    }
  ]
}
```

---

## 🧬 Fraud Detection Heuristics

| Check | Trigger | Risk Contribution |
|---|---|---|
| Experience Plausibility | experience > 45 years | +40 pts |
| Very High Experience | experience > 35 years | +15 pts |
| Skill Duplication | Duplicate entries in skills list | +15 pts |
| Keyword Stuffing | > 40 skills listed | +30 pts |
| Large Skill List | > 25 skills listed | +10 pts |
| Skill Coherence | 6+ domains with < 2 years exp | +20 pts |
| Project/Experience Ratio | 10+ projects with < 1 year exp | +10 pts |
| Cert Plausibility | 5+ certs with < 6 months exp | +15 pts |

**Risk Levels:** Low (< 40) · Medium (40–70) · High (> 70)

---

## 🌐 Skill Knowledge Graph (Sample)

```
React ──────────► JavaScript, HTML, CSS
Next.js ────────► React, JavaScript, Node.js
FastAPI ────────► Python, Pydantic
Django ─────────► Python
Spring Boot ────► Java, Spring
Kubernetes ─────► Docker, Linux
TensorFlow ─────► Python, NumPy
```

100+ relationships across the full graph in `app/data/skill_knowledge_base.py`.

---

## 🎓 Education Tier Scoring

| Qualification | Score |
|---|---|
| PhD | 100 |
| M.Tech / M.E | 88 |
| M.Sc | 85 |
| MBA / MCA | 80 |
| B.Tech / B.E | 75 |
| B.Sc / BCA | 65 |
| Diploma | 45 |

---

## 🤝 Integration with MERN Backend

The MERN team sends POST requests with the candidate JSON (already parsed from PDFs). No raw resume processing happens here — this module is **pure AI ranking logic**.

**Recommended integration pattern:**
```
MERN → POST /api/v1/rank-multiple-candidates → JSON rankings → Store in MongoDB
```

---

## 📈 Roadmap

- [ ] Redis caching for repeated job/candidate pairs
- [ ] Vector embeddings for deeper semantic skill matching (OpenAI / sentence-transformers)
- [ ] Historical ranking analytics endpoint
- [ ] Webhook support for async batch processing
- [ ] Admin dashboard UI

---

## 👨‍💻 Built For

**Zenvora HR Platform** · AI Engineering Team
Suitable for internship portfolios, GitHub showcases, and enterprise deployment.
