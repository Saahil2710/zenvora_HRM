"""
tests/test_ranking.py
─────────────────────
Integration tests for the Zenvora NeuroHR AI Ranking Engine.
Run with: pytest tests/ -v
"""

import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app

# ── Fixtures ──────────────────────────────────────────────────────────────────

SAMPLE_CANDIDATE = {
    "name": "Rahul Sharma",
    "skills": ["Python", "FastAPI", "SQL", "React"],
    "experience": 2,
    "education": "B.Tech",
    "projects": ["AI Resume Parser", "E-commerce Backend"],
    "certifications": ["AWS Cloud Practitioner"],
    "summary": "Backend engineer specialising in Python microservices.",
}

SAMPLE_JOB = {
    "job_role": "Backend Developer",
    "required_skills": ["Python", "FastAPI", "Docker", "SQL"],
    "required_experience": 2,
    "nice_to_have_skills": ["Redis"],
}


@pytest.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac


# ── Health ────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health(client):
    r = await client.get("/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "operational"


# ── Rank Single Candidate ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rank_candidate_returns_200(client):
    payload = {"candidate": SAMPLE_CANDIDATE, "job": SAMPLE_JOB}
    r = await client.post("/api/v1/rank-candidate", json=payload)
    assert r.status_code == 200


@pytest.mark.asyncio
async def test_rank_candidate_score_range(client):
    payload = {"candidate": SAMPLE_CANDIDATE, "job": SAMPLE_JOB}
    r = await client.post("/api/v1/rank-candidate", json=payload)
    data = r.json()
    assert 0 <= data["final_score"] <= 100


@pytest.mark.asyncio
async def test_rank_candidate_has_required_fields(client):
    payload = {"candidate": SAMPLE_CANDIDATE, "job": SAMPLE_JOB}
    r = await client.post("/api/v1/rank-candidate", json=payload)
    data = r.json()
    for field in [
        "candidate_name", "final_score", "ranking_level", "skill_analysis",
        "strengths", "weaknesses", "fraud_analysis", "hiring_recommendation",
        "candidate_tags",
    ]:
        assert field in data, f"Missing field: {field}"


@pytest.mark.asyncio
async def test_rank_candidate_detects_missing_docker(client):
    payload = {"candidate": SAMPLE_CANDIDATE, "job": SAMPLE_JOB}
    r = await client.post("/api/v1/rank-candidate", json=payload)
    data = r.json()
    missing = data["skill_analysis"]["missing_skills"]
    assert "Docker" in missing


@pytest.mark.asyncio
async def test_adaptive_weights_change_score(client):
    base_payload = {"candidate": SAMPLE_CANDIDATE, "job": SAMPLE_JOB}
    skills_heavy = {
        **base_payload,
        "weights": {
            "skills_weight": 80,
            "experience_weight": 10,
            "projects_weight": 5,
            "education_weight": 3,
            "certs_weight": 2,
        },
    }
    r1 = await client.post("/api/v1/rank-candidate", json=base_payload)
    r2 = await client.post("/api/v1/rank-candidate", json=skills_heavy)
    # Scores may differ when weights change
    assert r1.status_code == 200
    assert r2.status_code == 200


# ── Fraud Check ───────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_fraud_check_low_risk(client):
    payload = {"candidate": SAMPLE_CANDIDATE}
    r = await client.post("/api/v1/fraud-check", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert data["fraud_analysis"]["fraud_risk_level"] == "Low"


@pytest.mark.asyncio
async def test_fraud_check_high_experience(client):
    suspicious = {**SAMPLE_CANDIDATE, "experience": 60}
    payload = {"candidate": suspicious}
    r = await client.post("/api/v1/fraud-check", json=payload)
    assert r.status_code == 200
    data = r.json()
    # Experience of 60 years should trigger high fraud risk
    assert data["fraud_analysis"]["fraud_risk_level"] in ("Medium", "High")
    assert data["fraud_analysis"]["is_suspicious"] is True


# ── Batch Ranking ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rank_multiple_sorted(client):
    candidates = [
        {**SAMPLE_CANDIDATE, "name": "Alice", "skills": ["Python", "FastAPI", "Docker", "SQL"]},
        {**SAMPLE_CANDIDATE, "name": "Bob",   "skills": ["JavaScript"]},
    ]
    payload = {"candidates": candidates, "job": SAMPLE_JOB, "top_n": 2}
    r = await client.post("/api/v1/rank-multiple-candidates", json=payload)
    assert r.status_code == 200
    data = r.json()
    ranked = data["ranked_candidates"]
    assert ranked[0]["final_score"] >= ranked[1]["final_score"]
    assert ranked[0]["rank"] == 1


# ── Validation ────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_invalid_weights_rejected(client):
    payload = {
        "candidate": SAMPLE_CANDIDATE,
        "job": SAMPLE_JOB,
        "weights": {
            "skills_weight": 50,
            "experience_weight": 50,
            "projects_weight": 50,
            "education_weight": 50,
            "certs_weight": 50,
        },
    }
    r = await client.post("/api/v1/rank-candidate", json=payload)
    assert r.status_code == 422   # Pydantic validation error
